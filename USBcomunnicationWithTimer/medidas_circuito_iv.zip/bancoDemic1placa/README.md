Medidas retiradas no banco do demic com uma placa solar.

Se o ganho de tensão fosse aumentado, o sinal saturaria

vg = voltage gain
cg = current gain