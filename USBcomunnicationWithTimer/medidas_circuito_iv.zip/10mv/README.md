Medida retirada em bancada, com uma tensão de 10mV aplicada sobre os terminais da placa solar

cg = current gain
vg = voltage gain