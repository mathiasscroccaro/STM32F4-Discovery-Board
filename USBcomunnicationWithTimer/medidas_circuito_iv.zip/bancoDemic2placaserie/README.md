Medidas retiradas no banco do demic com duas placas em serie.

Se o ganho de tensão fosse aumentado, o sinal saturaria

vg = voltage gain
cg = current gain