Medida retirada em bancada, com uma tensão de 100mV aplicada sobre os terminais da placa solar

cg = current gain
vg = voltage gain